### Learning Outcomes

- Understood the concept of SPA using React.
- Gained experience with Material UI (MUI) component library.
- Learned how to use pre-built UI components like Button, TextField, Select, Rating, and Checkbox.