# Learning Outcome
- Learnt basic of React JS and it's working and features
- Learnt difference between SPA and MPA
- Learnt to create compoents in ReactJS 
